package com.example.study.route;

import com.example.study.repository.PersonRepository;
import com.example.study.routerFunction.PersonHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

@Component
public class Router {
    @Autowired
    private PersonRepository repository;

    private PersonHandler personHandler = new PersonHandler(repository);

    RouterFunction<ServerResponse> otherRoute = RouterFunctions.route()
            .GET("/other", RequestPredicates.contentType(MediaType.APPLICATION_JSON),
                    serverRequest -> ServerResponse.ok().bodyValue("Other")).build();

    RouterFunction<ServerResponse> route = RouterFunctions.route()
            .GET("/person/{id}", RequestPredicates.accept(MediaType.APPLICATION_JSON), personHandler::getPerson)
            .GET("/person",RequestPredicates.accept(MediaType.APPLICATION_JSON), personHandler::listPeople)
            .POST("/person",personHandler::createPerson)
            .add(otherRoute)
            .build();

    // 엔드포인트 중복 상속으로 변경
    RouterFunction<ServerResponse> inheritedRoute = RouterFunctions.route()
            .path("/person", builder ->
                    builder.GET("/{id}", RequestPredicates.accept(MediaType.APPLICATION_JSON), personHandler::getPerson)
                    .GET("", RequestPredicates.accept(MediaType.APPLICATION_JSON), personHandler::listPeople)
                    .POST("",personHandler::createPerson)
                    ).build();

    // 공통 헤더를 사용할 RouterFunction 만 Nest 안에 Consumer 에서 작성!
    RouterFunction<ServerResponse> inheritedAllRoute = RouterFunctions.route()
            .path("/person", builder -> builder
                .nest(RequestPredicates.accept(MediaType.APPLICATION_JSON), builder1 -> builder1
                        .GET("/{id}", personHandler::getPerson)
                        .GET("", personHandler::listPeople)
                        )
                .POST("", personHandler::createPerson)
            ).build();

}
