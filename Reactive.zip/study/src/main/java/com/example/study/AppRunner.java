package com.example.study;

import com.example.study.repository.PersonRepository;
import com.example.study.routerFunction.PersonHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.config.WebFluxConfigurer;
import org.springframework.web.reactive.function.server.RouterFunction;

import java.util.Arrays;

@Component
@Slf4j
public class AppRunner implements ApplicationRunner {

    @Autowired
    private PersonRepository repository;
    @Autowired
    private PersonHandler personHandler;
    @Qualifier("webConfig")
    @Autowired
    private WebFluxConfigurer webFluxConfigurer;
    @Autowired
    private RouterFunction<?> routerFunction;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        log.warn("리포지토리 : {}",repository.getClass().getSimpleName());
        log.warn("핸들러 : {}",personHandler.getClass().getSimpleName());
        log.warn("컨피그 : {}",webFluxConfigurer.getClass().getSimpleName());
        log.warn("라우터 : {}", routerFunction.getClass().getSimpleName());
    }
}
