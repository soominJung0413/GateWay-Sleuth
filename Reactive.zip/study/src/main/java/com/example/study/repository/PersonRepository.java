package com.example.study.repository;

import com.example.study.model.Person;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PersonRepository extends R2dbcRepository<Person, Long> {

}
