package com.example.study.config;

import com.example.study.routerFunction.PersonHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.web.reactive.config.CorsRegistry;
import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.web.reactive.config.WebFluxConfigurer;
import org.springframework.web.reactive.function.server.*;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@Configuration
@EnableWebFlux
public class WebConfig implements WebFluxConfigurer {

    private final PersonHandler personHandler;

    public WebConfig(PersonHandler personHandler) {
        this.personHandler = personHandler;
    }

    @Bean
    public RouterFunction<?> personHandlerRouterFunction() {
        return RouterFunctions.route().
                path("/person",builder -> builder
                    .nest(RequestPredicates.contentType(APPLICATION_JSON).and(RequestPredicates.accept(APPLICATION_JSON)),
                            builder1 -> builder1
                            .GET("/{id}",personHandler::getPerson)
                            .GET("",personHandler::listPeople)
                            .POST("",personHandler::createPerson)
                            .before(request -> ServerRequest.from(request).header("X-RequestHeader","Value").build())
                    )
                .after((request, serverResponse) -> {System.out.println("로그 작업"); return serverResponse;})
                .filter((request, next) -> {
                    if(request.queryParam("auth").get().equals("true")){
                        // 다음 필터나 핸들러 펑션
                        return next.handle(request);
                    } else {
                        return ServerResponse.status(HttpStatus.UNAUTHORIZED).build();
                    }
                })
                ).build();
    }

    @Override
    public void configureHttpMessageCodecs(ServerCodecConfigurer configurer) {
        configurer.defaultCodecs().enableLoggingRequestDetails(true);
    }

}
