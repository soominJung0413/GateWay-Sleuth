package com.example.study.routerFunction;


import com.example.study.model.Person;
import com.example.study.repository.PersonRepository;
import com.example.study.validation.PersonValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class PersonHandler {

    private final Validator validator = new PersonValidator();
    private final PersonRepository repository;

    @Autowired
    public PersonHandler(PersonRepository repository) {
        this.repository = repository;
    }

    // Flux 의 모든 Person 객체를 JSON 으로 직렬화하는 함수
    public Mono<ServerResponse> listPeople(ServerRequest request) {
        Flux<Person> people = repository.findAll();
        // 응답으로 보내면서 직렬화 ->  DecoderHttpMessageReader
        return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(people, Person.class);
    }

    public Mono<ServerResponse> createPerson(ServerRequest request) {
        Mono<ServerResponse> response = request.bodyToMono(Person.class).flatMap(p ->
                ServerResponse.ok().body(repository.save(p).log(), Person.class));

        return response;
    }

    public Mono<ServerResponse> getPerson(ServerRequest request) {
        System.out.println("체크");
        long personId = Long.valueOf(request.pathVariable("id"));

        return repository.findById(personId).flatMap(p ->
                ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).bodyValue(p))
                .switchIfEmpty(ServerResponse.notFound().build());
    }

    private void validate(Person person) {
        Errors error = new BeanPropertyBindingResult(person,"person");
        validator.validate(person,error);

        if(error.hasErrors()) {
            System.out.println("Error.");
        }
    }


}
