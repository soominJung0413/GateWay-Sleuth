package com.example.study.uri;

import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

public class URIMakeHelpers {

    // UriComponents 를 UriComponentBuilder 로생성
    public void study() {
        UriComponents uriComponents = UriComponentsBuilder
                .fromUriString("https://www.example.com/{id}")
                .queryParam("key", "{value}")
                .encode()
                .build();
        // UriComponents 로 URI 생성성
       URI toUri = uriComponents.expand("1", "myValue").toUri();

        //.buildAndExpect 사용
        URI uri = UriComponentsBuilder
                .fromUriString("https://www.exmample.com/{id}")
                .queryParam("key", "{value}")
                .encode()
                .buildAndExpand("1", "myValue")
                .toUri();

        // 템플릿 전체 작성 후 build 에 값을 넣어 줌
        URI build = UriComponentsBuilder
                .fromUriString("https://www.example.com/{id}?key={value}")
                .build("1", "myValue");
    }

    public void uriBuilderFactoryStudy() {
        String baseUrl = "https://example.org";
        DefaultUriBuilderFactory factory = new DefaultUriBuilderFactory(baseUrl);
        // UriBuilderFactory 아래에 EncodingMode 에 존재하는 상수
        factory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.TEMPLATE_AND_VALUES);

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setUriTemplateHandler(factory);

        String baseUrl1  = "https://test-1.org";
        DefaultUriBuilderFactory builderFactory = new DefaultUriBuilderFactory(baseUrl1);

        builderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.TEMPLATE_AND_VALUES);

        WebClient client = WebClient.builder().uriBuilderFactory(builderFactory).build();
    }
}
